import { describe, expect, it } from 'vitest';
import { testimonials } from '@/lib/teamlex';

describe('Teamlex review honesty', () => {
  it('contains no customer reviews because the four supplied screenshots contain none', () => {
    expect(testimonials).toEqual([]);
  });
});
