import { describe, expect, it } from 'vitest';
import { buildStudioMessageEmail, parseStudioMessage } from '@/lib/studio-message';

const validProject = {
  kind: 'project' as const,
  name: 'Jane Doe',
  email: 'jane@example.com',
  service: 'Music Promotion',
  details: 'I have a finished track and want help releasing it next month.',
};

describe('parseStudioMessage', () => {
  it('accepts a complete project inquiry', () => {
    const result = parseStudioMessage(validProject);
    expect(result.ok).toBe(true);
  });

  it('requires an email on project inquiries so the studio can reply', () => {
    const result = parseStudioMessage({ ...validProject, email: '' });
    expect(result).toEqual({ ok: false, error: 'Please add your email so we can reply.' });
  });

  it('rejects a malformed email', () => {
    const result = parseStudioMessage({ ...validProject, email: 'not-an-email' });
    expect(result).toEqual({ ok: false, error: 'Please enter a valid email address.' });
  });

  it('requires a star rating on reviews', () => {
    const result = parseStudioMessage({
      kind: 'review',
      name: 'Jane Doe',
      service: 'Mixing & Mastering',
      details: 'The master came back louder and cleaner than the demo I sent.',
    });
    expect(result).toEqual({ ok: false, error: 'Please choose a star rating.' });
  });

  it('allows a review with no email address', () => {
    const result = parseStudioMessage({
      kind: 'review',
      name: 'Jane Doe',
      service: 'Mixing & Mastering',
      rating: '4 out of 5 stars',
      details: 'The master came back louder and cleaner than the demo I sent.',
    });
    expect(result.ok).toBe(true);
  });

  it('drops submissions where the hidden honeypot field is filled', () => {
    const result = parseStudioMessage({ ...validProject, website: 'http://spam.example' });
    expect(result).toEqual({ ok: false, error: 'Your message was not sent.' });
  });

  it('removes line breaks so a submitted value cannot add email headers', () => {
    const result = parseStudioMessage({
      ...validProject,
      name: 'Jane\r\nBcc: victim@example.com',
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.message.name).not.toContain('\r');
      expect(result.message.name).not.toContain('\n');
      const { raw } = buildStudioMessageEmail(result.message);
      const [headers] = Buffer.from(raw, 'base64').toString('utf8').split('\r\n\r\n');
      expect(headers).not.toContain('Bcc:');
    }
  });

  it('trims over-long names instead of rejecting the message', () => {
    const result = parseStudioMessage({ ...validProject, name: 'A'.repeat(300) });
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.message.name).toHaveLength(100);
  });

  it('requires a project link to start with http', () => {
    const result = parseStudioMessage({ ...validProject, musicLink: 'spotify:track:123' });
    expect(result).toEqual({ ok: false, error: 'Please enter a link that starts with http.' });
  });
});

describe('buildStudioMessageEmail', () => {
  it('always addresses the studio inbox and replies to the visitor', () => {
    const result = parseStudioMessage(validProject);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const { subject, raw } = buildStudioMessageEmail(result.message);
    const decoded = Buffer.from(raw, 'base64').toString('utf8');
    expect(subject).toBe('Teamlex Studio project inquiry — Music Promotion');
    expect(decoded).toContain('To: teamlexstudio877@gmail.com');
    expect(decoded).toContain('Reply-To: jane@example.com');
    expect(decoded).toContain('Service: Music Promotion');
    expect(decoded).toContain('I have a finished track');
  });

  it('omits Reply-To when the sender gave no email', () => {
    const result = parseStudioMessage({
      kind: 'review',
      name: 'Jane Doe',
      service: 'Mixing & Mastering',
      rating: '5 out of 5 stars',
      details: 'The master came back louder and cleaner than the demo I sent.',
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const decoded = Buffer.from(buildStudioMessageEmail(result.message).raw, 'base64').toString(
      'utf8',
    );
    expect(decoded).not.toContain('Reply-To:');
    expect(decoded).toContain('Rating: 5 out of 5 stars');
  });

  it('retains the review text word for word, including symbols', () => {
    const result = parseStudioMessage({
      kind: 'review',
      name: 'Jane & Co',
      service: 'Mixing & Mastering',
      rating: '3 out of 5 stars',
      details: 'Loud & clean — better than my demo.',
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const decoded = Buffer.from(buildStudioMessageEmail(result.message).raw, 'base64').toString(
      'utf8',
    );
    expect(decoded).toContain('Name: Jane & Co');
    expect(decoded).toContain('Service received: Mixing & Mastering');
    expect(decoded).toContain('Loud & clean — better than my demo.');
  });
});
