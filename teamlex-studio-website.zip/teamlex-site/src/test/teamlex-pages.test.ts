import { describe, expect, it } from 'vitest';
import { projects, services } from '@/lib/teamlex';

describe('Teamlex multi-page data', () => {
  it('keeps all nine services with unique slugs', () => {
    expect(services).toHaveLength(9);
    expect(new Set(services.map(s => s.slug)).size).toBe(9);
  });
  it('labels every placeholder portfolio project as Concept / Demo', () => {
    expect(projects.length).toBeGreaterThan(0);
    expect(projects.every(p => p.demo)).toBe(true);
  });
  it('gives every service the detail sections its page renders', () => {
    for (const s of services) {
      expect(s.forWhom.length).toBeGreaterThan(0);
      expect(s.includes.length).toBeGreaterThan(0);
      expect(s.clientProvides.length).toBeGreaterThan(0);
      expect(s.process.length).toBeGreaterThan(0);
    }
  });
});
